// chess.c

inherit SKILL;

string type() { return "technic"; }

void skill_improved(object me)
{}

int valid_learn(object me)
{
    return 1;
}
