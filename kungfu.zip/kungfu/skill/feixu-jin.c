inherit SKILL;

string type() { return "knowledge"; }

int difficult_level()
{
        return 4000;
}