inherit SKILL; 
string type() { return "knowledge"; } 

