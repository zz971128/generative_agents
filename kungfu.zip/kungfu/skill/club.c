// club.c

inherit SKILL;
