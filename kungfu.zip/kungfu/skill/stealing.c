// stealing.c
// modified by Venus Oct.1997
inherit SKILL;

