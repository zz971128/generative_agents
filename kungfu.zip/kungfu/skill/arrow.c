inherit SKILL;
