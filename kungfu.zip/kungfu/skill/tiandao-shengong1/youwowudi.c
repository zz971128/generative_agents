// powerup.c 
// By haiyan

#include <ansi.h>

inherit F_CLEAN_UP;
string query_name() { return "����"ZJBR"�޵�"; }
void remove_effect(object me, int amount);

int exert(object me, object target)
{
    int skill;


    if (target != me)
        return notify_fail("��ֻ���������޵��������Լ���ս����\n");

    if ((int)me->query_skill("tiandao-shengong",1) < 100)
        return notify_fail("����������Ϊ̫�ͣ��޷�ʩչ�������޵С���\n");

    if ((int)me->query("neili") < 200)
        return notify_fail("�������������\n");

    if ((int)me->query_temp("powerup"))
        return notify_fail("���Ѿ����˹����ˡ�\n");

    skill = me->query_skill("force");
    me->add("neili", -120);
    me->receive_damage("qi", 0);
    message_combatd(HIR "$N" HIR "������Х��˫Ŀ�����⣬����Ѹ����ɢ��ȫ����"
                    "��ʱ�������˷�ӿ�������ѵ���\n" NOR, me);
    me->add_temp("apply/attack", skill / 2);
    me->add_temp("apply/defense", skill / 2);
    me->add_temp("apply/armor", skill);
    me->add_temp("apply/damage", skill * 4);
    me->add_temp("apply/unarmed_damage", skill * 4);
    me->add_temp("apply/dodge", skill / 2);
    me->add_temp("apply/unarmed", skill / 2);
    me->add_temp("apply/cuff", skill / 2);
    me->add_temp("apply/strike", skill / 2);
    me->add_temp("apply/finger", skill / 2);
    me->add_temp("apply/hand", skill / 2);
    me->add_temp("apply/claw", skill / 2);
    me->add_temp("apply/blade", skill / 2);
    me->add_temp("apply/sword", skill / 2);
    me->add_temp("apply/stick", skill / 2);
    me->add_temp("apply/club", skill / 2);
    me->add_temp("apply/staff", skill / 2);
    me->add_temp("apply/whip", skill / 2);
    me->add_temp("apply/hammer", skill / 2);
    me->add_temp("apply/dagger", skill / 2);
    me->add_temp("apply/parry", skill / 2);



    me->set_temp("powerup", 1);

    me->start_call_out((:call_other, __FILE__, "remove_effect", me,
                         skill:), skill);
    if (me->is_fighting()) me->start_busy(3);

    return 1;
}

void remove_effect(object me, int amount)
{
    if (me->query_temp("powerup"))
    {
        me->add_temp("apply/attack", -amount  / 2);
        me->add_temp("apply/defense", -amount / 2);
        me->add_temp("apply/armor", -amount);
        me->add_temp("apply/damage", -amount  * 4);
        me->add_temp("apply/unarmed_damage", -amount  * 4);
        me->add_temp("apply/dodge", -amount / 2);
        me->add_temp("apply/unarmed", -amount / 2);
        me->add_temp("apply/cuff", -amount / 2);
        me->add_temp("apply/strike", -amount / 2);
        me->add_temp("apply/finger", -amount / 2);
        me->add_temp("apply/hand", -amount / 2);
        me->add_temp("apply/claw", -amount / 2);
        me->add_temp("apply/blade", -amount / 2);
        me->add_temp("apply/sword", -amount / 2);
        me->add_temp("apply/stick", -amount / 2);
        me->add_temp("apply/club", -amount / 2);
        me->add_temp("apply/staff", -amount / 2);
        me->add_temp("apply/whip", -amount / 2);
        me->add_temp("apply/hammer", -amount / 2);
        me->add_temp("apply/dagger", -amount / 2);
        me->add_temp("apply/parry", -amount / 2);

        me->delete_temp("powerup");
        tell_object(me, "��������޵�������ϣ��������ջص��\n");
    }
}

