// powerup.c 
// By haiyan

#include <ansi.h>

inherit F_CLEAN_UP;
string *force_name = ({ NOR + HIB "�������", HIY "�����Ϊ",
                        HIR "̫������",}); 
string name() { return HIR "����" NOR; }
string query_name() { return "����"; }
void remove_effect(object me, int amount);

int exert(object me, object target)
{
    int skill;
    string name;
    name = force_name[random(sizeof(force_name))];


    if (target != me)
        return notify_fail("��ֻ���������������Լ���ս����\n");

    if ((int)me->query_skill("taishang-wangqingjue",1) < 100)
        return notify_fail("���̫���������Ϊ̫�ͣ��޷�ʩչ�����项��\n");

    if ((int)me->query("neili") < 200)
        return notify_fail("�������������\n");

    if ((int)me->query_temp("powerup")||
	(int)me->query_temp("huaxue")||
	(int)me->query_temp("leidong")||
	(int)me->query_temp("badao-dasha")||
	(int)me->query_temp("dugu_finger")||
	(int)me->query_temp("jingang")||
	(int)me->query_temp("fireice"))	
        return notify_fail("���Ѿ����˹����ˡ�\n");

    skill = me->query_skill("force");
    me->add("neili", -120);
    me->receive_damage("qi", 0);
	
    message_combatd(HIW "$N" HIW "΢һ��������̫�������֮��" + name +
                        HIW "����\n" NOR, me);
						
    me->add_temp("apply/attack", skill / 2);
    me->add_temp("apply/defense", skill / 2);
    me->add_temp("apply/armor", skill);
    me->add_temp("apply/damage", skill * 4);
    me->add_temp("apply/unarmed_damage", skill * 4);
    me->add_temp("apply/dodge", skill / 2);
    me->add_temp("apply/finger", skill / 2);
    me->add_temp("apply/parry", skill / 2);



    me->set_temp("powerup", 1);
	me->set_temp("huaxue", 1);
	me->set_temp("leidong", 1);
	me->set_temp("badao-dasha", 1);
	me->set_temp("dugu_finger", 1);
	me->set_temp("jingang", 1);
	me->set_temp("fireice", 1);
	
    me->start_call_out((:call_other, __FILE__, "remove_effect", me,
                         skill:), skill);
    if (me->is_fighting()) me->start_busy(3);

    return 1;
}

void remove_effect(object me, int amount)
{
    if (me->query_temp("powerup"))
    {
        me->add_temp("apply/attack", -amount  / 2);
        me->add_temp("apply/defense", -amount / 2);
        me->add_temp("apply/armor", -amount);
        me->add_temp("apply/damage", -amount  * 4);
        me->add_temp("apply/unarmed_damage", -amount  * 4);
        me->add_temp("apply/dodge", -amount / 2);
        me->add_temp("apply/finger", -amount / 2);
        me->add_temp("apply/parry", -amount / 2);

        me->delete_temp("powerup");
		me->delete_temp("huaxue");
		me->delete_temp("leidong");
        me->delete_temp("badao-dasha");
		me->delete_temp("dugu_finger");
		me->delete_temp("jingang");
		me->delete_temp("fireice");
        tell_object(me, "�������������ϣ��������ջص��\n");
    }
}

