// medical.c

inherit SKILL_D("literate");

void create()
{
	replace_program(SKILL_D("literate"));
}
