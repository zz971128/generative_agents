// chongxu.c ����

#include <ansi.h>

inherit "/inherit/char/punisher";

void create()
{
	set_name("���µ�һ", ({ "���µ�һ" }));
	set("long",  "���������µ�һ��\n");
	set("gender", "����");
	set("age", 55);
	set("attitude", "peaceful");
	set("shen_type", 1);
	set("str", 5000);
	set("int", 5000);
	set("con", 5000);
	set("dex", 5000);

	set("max_qi", 60000);
	set("max_jing", 30000);
	set("neili", 75000);
	set("max_neili", 75000);
	set("jiali", 300);
	set("combat_exp", 2500000);
	set("score", 10000000);

	set_skill("force", 5000);
	set_skill("dodge", 5000);
	set_skill("unarmed", 5000);
	set_skill("strike", 5000);
	set_skill("hand", 5000);
	set_skill("parry", 5000);
	set_skill("sword", 5000);
	set_skill("���µ�һ", 5000);
  	set_skill("taoism", 5000);
	set_skill("literate", 5000);
	set_skill("medical", 5000);
      set_skill("martial-cognize", 5000);
      map_skill("force", "���µ�һ");
      map_skill("unarmed", "���µ�һ");
      map_skill("strike", "���µ�һ");
      map_skill("parry", "���µ�һ");
      map_skill("dodge", "���µ�һ");
        set_temp("apply/attack", 1000000000);
        set_temp("apply/defense", 1000000000);
        set_temp("apply/armor", 1000000000);
        set_temp("apply/damage", 1000000000);


	set("chat_chance_combat", 12000000);
	set("chat_msg_combat", ({
		(: perform_action, "sword.tianjian" :),
		(: perform_action, "sword.tianyi" :),
		(: perform_action, "sword.weishe" :),
		(: exert_function, "recover" :),
	}));

	setup();
	carry_object("/clone/weapon/changjian")->wield();
	carry_object("/d/wudang/obj/whiterobe")->wear();
}
