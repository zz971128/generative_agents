// hongri.c ���շ���

#include <ansi.h>

inherit "/inherit/char/punisher";

void create()
{
	set_name("���շ���", ({ "hongri fawang", "fawang" }));
	set("long",  "������ȥ��һ����ɮ����ǰ����һ������̫����\n");
	set("gender", "����");
	set("age", 62);
	set("attitude", "peaceful");
	set("shen_type", 1);
	set("str", 600);
	set("int", 600);
	set("con", 600);
	set("dex", 600);

	set("max_qi", 60000);
	set("max_jing", 30000);
	set("neili", 75000);
	set("max_neili", 75000);
	set("jiali", 300);
	set("combat_exp", 2500000);
	set("score", 10000000);

	set_skill("lamaism", 5000);
	set_skill("literate", 5000);
	set_skill("force", 5000);
	set_skill("parry", 5000);
	set_skill("blade", 5000);
	set_skill("tiandaodao",5000);
	set_skill("xue-dao",5000);
	set_skill("sword", 5000);
	set_skill("mingwang-jian", 5000);
	set_skill("dodge", 5000);
	set_skill("mizong-neigong", 5000);
	set_skill("xuehai-mogong", 5000);
	set_skill("shenkong-xing", 5000);
	set_skill("hand", 2000);
	set_skill("dashou-yin", 2000);
	set_skill("cuff", 2000);
	set_skill("yujiamu-quan", 2000);
       set_skill("martial-cognize", 5000);

	map_skill("force", "xuehai-mogong");
	map_skill("dodge", "shenkong-xing");
	map_skill("hand", "dashou-yin");
	map_skill("cuff", "yujiamu-quan");
	map_skill("parry", "xue-dao");
	map_skill("blade", "tiandaodao");
	map_skill("sword", "mingwang-jian");

	prepare_skill("cuff", "yujiamu-quan");
	prepare_skill("hand", "dashou-yin");

	create_family("Ѫ����", 0, "����");
	set("class", "bonze");

	set("chat_chance_combat", 120);
	set("chat_msg_combat", ({
		(: perform_action, "blade.modao" :),
		(: perform_action, "blade.tianyi" :),
		(: perform_action, "blade.weishe" :),
		(: perform_action, "hand.jingang" :),
		(: perform_action, "cuff.chen" :),
		(: exert_function, "recover" :),
	}));

	setup();
	carry_object("/d/xueshan/obj/y-jiasha")->wear();
	carry_object("/d/xuedao/obj/xblade")->wield();
}
