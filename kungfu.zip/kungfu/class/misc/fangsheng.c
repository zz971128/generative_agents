// fangsheng.c

inherit "/inherit/char/punisher";

void create()
{
	set_name("����", ({ "fang sheng", "fang" }));
	set("long", "����Ŀ�Ⱥͣ���Ȼ��һ�õ���ɮ��\n");

	set("gender", "����");
	set("attitude", "friendly");
	set("class", "bonze");

	set("age", 40);
	set("shen_type", 1);
	set("str", 500);
	set("int", 500);
	set("con", 500);
	set("dex", 500);
	set("max_qi", 60000);
	set("max_jing", 30000);
	set("neili", 75000);
	set("max_neili", 75000);
	set("jiali", 300);
	set("combat_exp", 2450000);
	set("score", 10000000);

	set_skill("force", 5000);
	set_skill("hunyuan-yiqi", 5000);
	set_skill("dodge", 2600);
	set_skill("shaolin-shenfa", 5000);
	set_skill("sword", 5000);
	set_skill("finger", 5000);
	set_skill("strike", 5000);
	set_skill("hand", 5000);
	set_skill("claw", 5000);
	set_skill("parry", 5000);
	set_skill("tiandaojian", 5000);
	set_skill("tiandaoquan", 5000);
	set_skill("nianhua-zhi", 5000);
	set_skill("sanhua-zhang", 5000);
	set_skill("fengyun-shou", 5000);
	set_skill("longzhua-gong", 5000);
	set_skill("buddhism", 2600);
	set_skill("literate", 1200);
        set_skill("martial-cognize", 5000);

	map_skill("force", "hunyuan-yiqi");
	map_skill("dodge", "shaolin-shenfa");
	map_skill("sword", "tiandaojian");
	map_skill("finger", "nianhua-zhi");
	map_skill("strike", "sanhua-zhang");
	map_skill("hand", "fengyun-shou");
	map_skill("claw", "longzhua-gong");
	map_skill("parry", "nianhua-zhi");

	prepare_skill("finger", "nianhua-zhi");
	prepare_skill("strike", "sanhua-zhang");

	create_family("������", 0, "��ɮ");

	set("chat_chance_combat", 120);
	set("chat_msg_combat", ({
		(: perform_action, "sword.tianjian" :),
		(: perform_action, "sword.tianyi" :),
		(: perform_action, "sword.weishe" :),
		(: exert_function, "recover" :),
	}));

	setup();
	carry_object("/d/shaolin/obj/xuan-cloth")->wear();
      carry_object("/clone/weapon/gangjian")->wield();

}
