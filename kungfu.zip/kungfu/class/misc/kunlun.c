
#include <ansi.h>

inherit "/inherit/char/punisher";

void create()
{
        set_name("������ʿ", ({ "yin shi", "yin", "shi" }));
        set("long",  "�����������ɵĸ��֣���˵����������ɽ�С�\n");
        set("gender", "����");
        set("age", 55);
        set("attitude", "peaceful");
        set("shen_type", 1);
        set("str", 32);
        set("int", 25);
        set("con", 25);
        set("dex", 25);
        set("max_qi", 50000);
        set("max_jing", 30000);
        set("neili", 60000);
        set("max_neili", 6000);
        set("jiali", 300);
        set("combat_exp", 1600000);

        set_skill("force", 2200);
        set_skill("kunlun-xinfa", 2000);
        set_skill("liangyi-shengong", 2200);
        set_skill("dodge", 2000);
        set_skill("chuanyun-bu", 2000);
        set_skill("hand", 2000);
        set_skill("sanyin-shou", 2000);
        set_skill("cuff", 2000);
        set_skill("zhentian-quan", 2000);
        set_skill("parry", 2000);
        set_skill("sword", 2200);
        set_skill("kunlun-jian", 2200);
        set_skill("xunlei-jian", 2200);
        set_skill("zhengliangyi-jian", 2200);
        set_skill("throwing", 2000);
        set_skill("kunlun-qifa", 2000);
        set_skill("tanqin-jifa", 2400);
        set_skill("tieqin-yin", 2400);
        set_skill("literate", 2200);
        set_skill("martial-cognize", 2000);

        map_skill("force", "liangyi-shengong");
        map_skill("dodge", "chuanyun-bu");
        map_skill("parry", "zhengliangyi-jian");
        map_skill("sword", "kunlun-jian");
        map_skill("cuff", "zhentian-quan");
        map_skill("hand", "sanyin-shou");
        map_skill("throwing", "kunlun-qifa");
        map_skill("tanqin-jifa", "tieqin-yin");

        prepare_skill("strike", "kunlun-zhang");
        prepare_skill("cuff", "zhentian-quan");

        create_family("������", 0, "��ʿ");


        set("chat_chance_combat", 100);
        set("chat_msg_combat", ({
                (: perform_action, "sword.fanyin" :),
                (: perform_action, "throwing.liu" :),
                (: perform_action, "cuff.shi" :),
                (: perform_action, "hand.sun" :),
                (: exert_function, "recover" :),
                (: exert_function, "powerup" :),

        }) );


        set_temp("apply/attack", 1000);
        set_temp("apply/damage", 1000);
        set_temp("apply/unarmed_damage", 1000);
        set_temp("apply/armor", 2000);

        setup();
        carry_object("/clone/weapon/changjian")->wield();
        carry_object("/d/wudang/obj/whiterobe")->wear();
}
