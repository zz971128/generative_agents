
#include <ansi.h>

inherit "/inherit/char/punisher";

void create()
{
        set_name("��������ʿ", ({ "yin shi", "yin", "shi" }));
        set("long",  "�����������ǵĸ��֣���˵����������ɽ�С�\n");
        set("gender", "����");
        set("age", 55);
        set("attitude", "peaceful");
      set("shen_type", 1);
        set("str", 30);
        set("int", 30);
        set("con", 30);
        set("dex", 30);
        set("class","lingxiao");
        set("max_qi", 58000);
        set("max_jing", 30000);
        set("neili", 45000);
        set("max_neili", 45000);
        set("jiali", 180);
        set("combat_exp", 4000000);

        set_skill("force", 2000);
        set_skill("xueshan-neigong", 2000);
        set_skill("dodge", 2000);
        set_skill("taxue-wuhen", 2000);
        set_skill("cuff", 1800);
        set_skill("lingxiao-quan", 1800);
        set_skill("strike", 1800);
        set_skill("piaoxu-zhang", 1800);
        set_skill("sword", 2200);
        set_skill("hanmei-jian", 2200);
        set_skill("yunhe-jian", 2200);
        set_skill("xueshan-jian", 2200);
        set_skill("parry", 2000);
        set_skill("literate", 2000);
        set_skill("martial-cognize", 1500);

        map_skill("force", "xueshan-neigong");
        map_skill("dodge", "taxue-wuhen");
        map_skill("cuff", "lingxiao-quan");
        map_skill("strike", "piaoxu-zhang");
        map_skill("sword", "xueshan-jian");
        map_skill("parry", "yunhe-jian");

        prepare_skill("strike", "piaoxu-zhang");
        prepare_skill("cuff", "lingxiao-quan");

        create_family("������", 0, "��ʿ");

        set("chat_chance_combat", 120);
        set("chat_msg_combat", ({
                (: perform_action, "sword.hui" :),
                (: perform_action, "sword.chu" :),
                (: perform_action, "cuff.jue" :),
                (: perform_action, "strike.piao" :),
                (: exert_function, "recover" :),
                (: exert_function, "powerup" :),
        }));


        set_temp("apply/attack", 100);
        set_temp("apply/damage", 100);
        set_temp("apply/unarmed_damage", 100);
        set_temp("apply/armor", 200);



        setup();
        carry_object("/clone/weapon/changjian")->wield();
        carry_object("/d/wudang/obj/whiterobe")->wear();
}
