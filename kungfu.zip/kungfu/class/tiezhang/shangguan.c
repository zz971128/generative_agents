// shangguan.c

inherit NPC;
inherit F_MASTER;
inherit F_QUESTER;
#define MASTER_D "/adm/daemons/masterd"
void create()
{
        set_name("�Ϲٽ���", ({ "shangguan jiannan", "jiannan", "shangguan"}));
        set("long", "����������������ư���ϴ�����-�Ϲٽ��ϡ�\n");
        set("gender", "����");
        set("age", 70);
        set("attitude", "peaceful");
        set("shen_type", 1);
        set("str", 35);
        set("int", 30);
        set("con", 28);
        set("dex", 35);

        set("max_qi", 4000);
        set("max_jing", 3000);
        set("neili", 4000);
        set("max_neili", 4000);
        set("jiali", 200);
        set("combat_exp", 1000000);
        set("score", 400000);

        set_skill("force", 300);
        set_skill("guiyuan-tunafa", 300);
        set_skill("dodge", 300);
        set_skill("shuishangpiao", 300);
        set_skill("club", 300);
        set_skill("tiexue-qiang", 300);
        set_skill("zhongping-qiang", 300);
        set_skill("strike", 300);
        set_skill("zhusha-zhang", 300);
        set_skill("tie-zhang", 300);
        set_skill("parry", 300);
        set_skill("literate", 300);

        map_skill("force", "guiyuan-tunafa");
        map_skill("dodge", "shuishangpiao");
        map_skill("club", "tiexue-qiang");
        map_skill("strike", "tie-zhang");
        map_skill("parry", "tie-zhang");
        prepare_skill("strike", "tie-zhang");

        set("env/wimpy", 60);
        set("chat_chance_combat", 70);
        set("chat_msg_combat", ({
                (: command("unwield qiang") :),
                (: command("wield qiang") :),
                (: perform_action, "strike.zhangdao" :),
                (: exert_function, "powerup" :),
                (: exert_function, "recover" :),
        }) );

        create_family("���ư�", 13, "����");
        setup();
        carry_object(__DIR__"obj/yellowcloth")->wear();
        //carry_object(WEAPON_DIR+"spear/yinqiang")->wield();
}

void attempt_apprentice(object me)
{
        if(me->query_skill("guiyuan-tunafa", 1) < 100)
                command("say ��Ĺ�Ԫ���ɷ�����̫���ˡ�\n");
        else
        {
                command( "say �ðɣ��Ҿ��������ˡ������ҵ��书��Ҫ��������Ϲ�ͷһ���������ɽ�����ˡ�");
                command("recruit "+me->query("id"));
        }
}
