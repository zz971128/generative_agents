// This program is a part of NITAN MudLIB

#include <ansi.h>

inherit NPC;
inherit F_QUESTER;

void create()
{
        set_name("ؼ������", ({"nljfdxpz"}));
        set("nickname", HIY "��������" NOR );
        set("gender", "����");
        set("age", 18);
        set("long", "������ɹ����ŵ��ӣ��������С�\n");
        set("attitude", "peaceful");

        set("per", 21);
        set("str", 30);
        set("int", 30);
        set("con", 30);
        set("dex", 30);

        set("qi", 3000);
        set("max_qi", 3000);
        set("jing", 1000);
        set("max_jing", 1000);
        set("neili", 3000);
        set("max_neili", 3000);
        set("jiali", 300);

        set("combat_exp", 1500000);
        set("score", 0);

        set_skill("force", 180);
        set_skill("dodge", 180);
        set_skill("strike", 180);
        set_skill("cuff", 180);
        set_skill("sword", 180);
        set_skill("blade", 180);
        set_skill("parry", 150);
        set_skill("literate", 110);
        
        create_family("����ɢ��", 2, "����");

        set_temp("apply/attack", 180);
        set_temp("apply/damage", 180);
        set_temp("apply/unarmed_damage", 180);
        set_temp("apply/armor", 180);
		
	     setup();
        carry_object("/clone/misc/cloth")->wear();
        carry_object("/clone/weapon/gangjian")->wield();
        add_money("silver",70);
}