// zhangsan.c

#include <ansi.h>

inherit NPC;

void create()
{
	set_name("����", ({ "zhang san", "zhang", "san" }));
	set("title", HIY "���͵�����ʹ��" NOR);
	set("gender", "����");
	set("age", 37);
	set("long",
	      "���Ǹ���������ʮ����ĺ��ӣ����ķ��֣���ɫ����\n"
	);

	set("str", 36);
	set("int", 35);
	set("con", 34);
	set("dex", 37);

	set_temp("apply/armor", 1500);
	set_temp("apply/damage", 100);
	set_temp("apply/unarmed_damage", 100);

	set("qi", 9000);
	set("max_qi", 9000);
	set("jing", 20000);
	set("max_jing", 20000);
	set("neili", 85000);
	set("max_neili", 85000);
	set("jiali", 500);
	set("combat_exp", 10000000);
	set("score", 10000000);

	set_skill("force", 800);
	set_skill("taixuan-gong", 800);
	set_skill("dodge", 800);
	set_skill("taixuan-gong", 800);
	set_skill("unarmed", 800);
	set_skill("taixuan-gong", 800);
	set_skill("parry", 800);
	set_skill("martial-cognize", 800);
	set_skill("count", 800);

	map_skill("force", "taixuan-gong");
	map_skill("dodge", "taixuan-gong");
	map_skill("unarmed", "taixuan-gong");
	map_skill("parry", "taixuan-gong");

	set("chat_chance_combat", 120);
	set("chat_msg_combat", ({
		(: exert_function, "powerup" :),
		(: perform_action, "unarmed.taixuan" :),
	}) );
	create_family("���͵�", 0, "����ʹ��");
	setup();

	carry_object("/clone/misc/cloth")->wear();
}
