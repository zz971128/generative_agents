
#include <ansi.h>
inherit "inherit/char/first";

void create()
{
        set("master_dir",CLASS_D("songshan")+"/zuo");
        set("start_room","/d/songshan/chanyuan");
        ::create();
}

string zm_apply()
{
        return ::zm_apply();
}
