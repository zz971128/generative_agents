// Npc: /kungfu/class/shaolin/xuan-tong.c
// Date: YZC 96/01/19

inherit NPC;
inherit F_MASTER;

#include "xuan.h"

void create()
{
	set_name("���Ŵ�ʦ", ({
		"xuanji dashi",
		"xuanji",
		"dashi",
	}));
	set("long",
		"����һλ�����ü����ɮ������һϮ��˿�ػ����ġ������ĸߴ�\n"
		"���ֹ�ϥ��˫Ŀ������գ�ȴ��ʱ���һ�ƾ��⡣\n"
	);

	set("nickname", "����Ժ����");
	set("gender", "����");
	set("attitude", "friendly");
	set("class", "bonze");

	set("age", 70);
	set("shen_type", 1);
	set("str", 30);
	set("int", 30);
	set("con", 30);
	set("dex", 30);
	set("max_qi", 2500);
	set("max_jing", 1000);
	set("neili", 3500);
	set("max_neili", 3500);
	set("jiali", 50);
	set("combat_exp", 1100000);

	set_skill("force", 160);
	set_skill("hunyuan-yiqi", 160);
	set_skill("strike", 160);
	set_skill("yipai-liangsan", 160);
	set_skill("shaolin-xinfa", 150);
	set_skill("dodge", 150);
	set_skill("shaolin-shenfa", 150);
	set_skill("parry", 150);
	set_skill("claw", 150);

	set_skill("longzhua-gong", 160);
	set_skill("yipai-liangsan", 160);
	set_skill("buddhism", 150);
	set_skill("literate", 150);
	set_skill("medical", 180);
	set_skill("shaolin-yishu", 180);

	map_skill("force", "hunyuan-yiqi");
	map_skill("parry", "longzhua-gong");
	map_skill("dodge", "shaolin-shenfa");
	map_skill("claw", "longzhua-gong");
	map_skill("parry", "yingzhua-gong");
	map_skill("strike", "yipai-liangsan");

	prepare_skill("strike", "yipai-liangsan");

	create_family("������", 36, "����");

	set("chat_chance_combat", 120);
	set("chat_msg_combat", ({
		(: exert_function, "recover" :),
		(: exert_function, "powerup" :),
		(: perform_action, "claw.zhua" :),
	}));

	setup();

	carry_object("/d/shaolin/obj/xuan-cloth")->wear();
}
