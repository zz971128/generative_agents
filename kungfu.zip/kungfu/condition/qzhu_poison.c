// poison.c

inherit F_CLEAN_UP;
inherit POISON;

string name() { return "poison"; }
