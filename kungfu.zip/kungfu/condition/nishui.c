#include <ansi.h>

int update_condition(object me, int duration)
{
int dam;
	if (me->query("neili") >= 40000) dam = 5000 + random(10000);
	else if (me->query("neili") > 30000) dam = 5000 + random(20000);
	else if (me->query("neili") > 20000) dam = 5000 + random(50000);
	else if (me->query("neili") > 10000) dam = 5000 + random(150000);
	else if (me->query("neili") > 5000) dam = 5000 + random(200000);
	else dam = 5000 + random(5000);

	me->receive_wound("qi", dam * 2);
	me->receive_wound("jing", dam / 20);
	me->apply_condition("nishui", duration);
	
	if( duration < 1 )
	tell_object(me, HIW "��Ĩȥ�������ϵ���ͣ�ֻ�е������Ƕ�ô�����£�"NOR"\n" );
	else
	tell_object(me, HIW "��е�һ�����ƣ�"NOR"\n" );
	if( duration < 1 ) 
		return 0;
	return 1;
}

