#include <ansi.h>
#include <condition.h>

inherit F_CLEAN_UP;

